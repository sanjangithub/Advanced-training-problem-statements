public class ArrayFunctions 
{
    public static void main(String[] args) 
    {
        storingAt15 s1 = new storingAt15();
        storingAverageArrayAt16 s2 = new storingAverageArrayAt16();
        storedSmallestAt17 s3 = new storedSmallestAt17();
        s1.method1();
        s2.method2();
        s3.method3();
    }
}

class storingAt15
{
    void method1()
    {
        int a[] ={1, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0,0};
        
        int sum = 0;
        for (int i : a)
        sum += i;
        a[15]=sum;
        System.out.println("The sum of the index elements 0-14 elements stored at element 15 is : "+a[15]);
    }
}

class storingAverageArrayAt16
{
    void method2()
    {
        int a[] ={1, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0,0};
        
        int sum = 0;
        for (int i : a)
        sum = sum+i;
        int avg = sum/2;
        a[16]=avg;
        System.out.println("The avg of the index elements 0-14 elements stored at element 16 is : "+a[16]);
    }
}

class storedSmallestAt17
{
    void method3()
    {
        int a[] ={1, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0,0};
        int min=a[0];
        for(int i=0;i<a.length-15;i++)
        {
            if(a[i]<min) min=a[i];
        }

        a[17]=min;
        System.out.println("The smallest element in the array which is stored at element 17 is : "+a[17]);
    }
}