 
import java.util.*;
 
public class ListingNEvenNumbers{
 
    public static void main(String []args)
    {
        int number,ival;
         
        try (Scanner scan = new Scanner(System.in)) {
            System.out.print("Enter value n : ");
            number = scan.nextInt();
        }
         
        for(ival=1; ival<number; ival++)
        {
            if(ival%2==0)
                System.out.print(ival+" ");
        }   

        System.out.println();
         
    }
}