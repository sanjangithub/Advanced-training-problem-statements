public class book2 {
	
	public void createBooks() {
		book book[] = new book[2];		 
		book[0] = new book("Java Programing ", 350.50);
		book[1] = new book("Let Us C", 200.00);
	     
		 for(int i = 0; i<book.length; i++) {
	    	  book[i].display();
		         System.out.println(" ");
	      }
	      }
	
	public void showBooks() {
		  	createBooks();
		
	}
	public static void main(String args[])  {
		book2 c1 = new book2();  
		c1.showBooks();
	   
	      }
	   }
