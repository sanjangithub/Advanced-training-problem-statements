public class Flute extends Method {

	@Override
	public void play() {
		System.out.println("Flute is playing  toot toot toot toot");

	}

}
