public abstract class Method {
	public abstract void play();
}
