class Rectangle {
	private int length;
	private int breadth;

	public Rectangle() {
	}

	public Rectangle(int length, int breadth) {
		this.length = length;
		this.breadth = breadth;
	}

	public void printData() {
		System.out.println("Length: " + length);
		System.out.println("Breadth: " + breadth);
	}

	public void printArea() {
		int area = length * breadth;
		System.out.println("Area: " + area);
	}

	public void printPerimeter() {
		int perimeter = 2 * (length + breadth);
		System.out.println("Perimeter: " + perimeter);
	}
}


public class App {

	public static void main(String[] args) {
	
		Rectangle r1 = new Rectangle();
		Rectangle r2 = new Rectangle(4, 4);
		Rectangle r3 = new Rectangle(15,14);
		Rectangle r4 = new Rectangle(12,21);
		Rectangle r5 = new Rectangle(17,33);
		Rectangle r6 = new Rectangle(19,45);
        Rectangle r7 = new Rectangle(16,35);
		Rectangle r8 = new Rectangle(33,41);
		space s = new space();
		r1.printData();
		r1.printArea();
		r1.printPerimeter();
        s.sp();

		r2.printData();
		r2.printArea();
		r2.printPerimeter();
		s.sp();

		r3.printArea();
		r3.printData();
		r3.printPerimeter();
		s.sp();

		r4.printArea();
		r3.printData();
		r3.printPerimeter();
		s.sp();

		r5.printArea();
		r3.printData();
		r3.printPerimeter();
		s.sp();

		r6.printArea();
		r3.printData();
		r3.printPerimeter();
		s.sp();

		r7.printArea();
		r3.printData();
		r3.printPerimeter();
		s.sp();

		r8.printArea();
		r3.printData();
		r3.printPerimeter();

	}
}

class space
{
	void sp()
	{
		System.out.println("\n****************************************");
	}
}